param (
    [string]$URL,
    [int]$X,
    [int]$Y,
    [int]$Width,
    [int]$Height
)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object Windows.Forms.Form
$form.FormBorderStyle = 'None'
$form.TopMost = $true
$form.Text = "HIXIMAGE"  # Set the title of the form

$image = [System.Drawing.Image]::FromStream((New-Object System.Net.WebClient).OpenRead($URL))
$pictureBox = New-Object Windows.Forms.PictureBox
$pictureBox.Image = $image
$pictureBox.Dock = 'Fill'
$pictureBox.SizeMode = 'Zoom'
$form.Controls.Add($pictureBox)

$form.StartPosition = 'Manual'
$form.Location = New-Object System.Drawing.Point($X, $Y)
$form.Size = New-Object System.Drawing.Size($Width, $Height)

# Variables to store mouse position
$mouseDown = $false
$startPoint = New-Object System.Drawing.Point

# Mouse down event
$form.Add_MouseDown({
    $mouseDown = $true
    $startPoint = [System.Windows.Forms.Cursor]::Position
})

# Mouse move event
$form.Add_MouseMove({
    if ($mouseDown) {
        $currentPoint = [System.Windows.Forms.Cursor]::Position
        $dx = $currentPoint.X - $startPoint.X
        $dy = $currentPoint.Y - $startPoint.Y
        $form.Location = New-Object System.Drawing.Point($form.Location.X + $dx, $form.Location.Y + $dy)
        $startPoint = $currentPoint
    }
})

# Mouse up event
$form.Add_MouseUp({
    $mouseDown = $false
})

$form.ShowDialog()